"""
Authors: Marshall Jones & Nathan Cox
File name: queens.py
Description:
This program displays a solution to the 8 Queens puzzle. Each row has a queen, and
none of the queens are in a location where they can damage each other, according
to chess rules. There are 4 functions in this program. The drawBoard function draws
the chess board and the queens in each row. The nextCombination function finds each
next possible configuration. The checkBoard function works with the nextCombination
function by returning whether or not the queen's position from the nextCombination
function works according to chess rules. The main function provides the first guess
from where the nextCombination function finds the next possible answer that works.
"""
def drawBoard(config): #This function draws the board that corresponds to config

    vertLine = "|"
    blank = ("|" + "   ")
    q = ("|" + " Q ")
    dashedLine = ("-"*33)

    for i in range(9):
        print(dashedLine)
        if i == 8:
            break
        a = config[i]
        b = 7 - a
        row = ((blank) * a) + (q) + ((blank) * b) + vertLine
        print(row)
    print(config)

def nextCombination(config): #This function returns the next configuration after the current config

    for i in range(1,9):
        answer = config
        if answer[-i] == 7:
            answer[-i] = 0
        elif answer[-i] < 7:
            answer[-i] += 1
            break
    return answer
    
def checkBoard(config): #This function returns whether this board is a solution

    n = 0
    for i in range(len(config)):
        for j in range(len(config)):
            if i != j:
                if config[i] == config[j]:
                    return False

    for i in range(len(config)): #this block prevents
        for j in range(len(config)):
            if i != j:
               difference = abs(j-i)
               config_dif = abs(config[j] - config [i])
               if difference == config_dif:
                   return False
                
    return True


def main(): #This is the main function

    guess = [0,0,0,0,0,0,0,0]

   
    while checkBoard(guess) == False:
        nextCombination(guess)
    drawBoard(guess)    
        

if __name__ == "__main__":
    main()
